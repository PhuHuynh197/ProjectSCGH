package com.example.Project_OpenID;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectOpenIdApplicationTests {

	@Test
	void contextLoads() {
	}

}
