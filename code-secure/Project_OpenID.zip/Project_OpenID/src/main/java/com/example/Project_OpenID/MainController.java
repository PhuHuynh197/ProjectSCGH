/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.Project_OpenID;

import java.security.Principal;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author THIS PC
 */
@RestController
public class MainController {
    @RequestMapping("/")
    public String Home(){
        return "Welcome to OpenID !";
    }
    @RequestMapping("/user")
    public Principal user(Principal user){
        return user;
    }
}